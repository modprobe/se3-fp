Bibliothek zur Vorlesung "Softwareentwicklung 3"
Autor: Leonie Dreschler-Fischer
Version 2.0 

Letzte Änderung 10.10.2010: 
Anpassung an DrRacket, Version 5.0.1